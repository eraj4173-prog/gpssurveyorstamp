// This file is replaced by the full SurveyStamp app in the final build.
// Open SurveyStamp-Preview.html in this zip to see the working app (blue theme, camera, GPS, stamp).
// For Vite + Capacitor build, copy the React code from that preview into this file, or use the preview html as dist.

import React from 'react';
export default function App(){
  return (
    <div style={{padding:24, fontFamily:'system-ui'}}>
      <h1>SurveyStamp</h1>
      <p>Open <b>SurveyStamp-Preview.html</b> in this folder to test the full working app.</p>
      <p>The file contains the complete blue-themed camera app with GPS stamp.</p>
      <p>For APK build, GitHub Actions will build using this structure. Make sure to copy the full App.tsx from the web artifact into src/App.tsx before first push if you want Vite build, or set webDir to the preview file location.</p>
      <p>Quick test: double-click SurveyStamp-Preview.html</p>
    </div>
  )
}